// ============================================================================
// PronoScope — Liste déroulante avec recherche (filtre championnat, équipes…)
// ============================================================================
import { useEffect, useMemo, useRef, useState } from 'react';
import { Icon } from '../icons';

/**
 * Composant_select enrichi : champ de recherche + liste filtrée + navigation clavier.
 *
 * Deux modes :
 *  - Sélection stricte (par défaut) : la valeur ne peut provenir que d'une
 *    option de la liste (filtres championnat, choix d'un match…).
 *  - `allowFree` : en plus de la liste, le texte tapé peut être validé tel
 *    quel (saisie libre des équipes/joueurs) — par la touche Entrée sans
 *    suggestion, ou simplement en cliquant ailleurs. Le nom saisi ne
 *    disparaît donc JAMAIS quand on passe au champ suivant.
 *
 * @param {{
 *   icon?: string, placeholder?: string, value?: any,
 *   options: Array<{value: any, label: string, hint?: string, icon?: string}>,
 *   onChange: (option|null) => void, onQuery?: (q: string) => void,
 *   align?: 'left'|'right', width?: number|string,
 *   allowFree?: boolean, clearable?: boolean
 * }} props
 */
export function SearchSelect({
  icon = 'search',
  placeholder = 'Rechercher…',
  value = null,
  options = [],
  onChange,
  onQuery,
  align = 'left',
  width = 260,
  allowFree = false,
  clearable = true,
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [focusIdx, setFocusIdx] = useState(0);
  const rootRef = useRef(null);
  const inputRef = useRef(null);
  const commitLockRef = useRef(false);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = q
      ? options.filter((o) => `${o.label} ${o.hint ?? ''}`.toLowerCase().includes(q))
      : options;
    return list.slice(0, 60);
  }, [options, query]);

  // Referme la liste quand on clique en dehors — et, en saisie libre,
  // VALIDE le texte tapé pour qu'il ne disparaisse jamais.
  useEffect(() => {
    if (!open) return undefined;
    const onDoc = (e) => {
      if (rootRef.current && !rootRef.current.contains(e.target)) {
        commitFreeText();
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('touchstart', onDoc);
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('touchstart', onDoc);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, query, options]);

  useEffect(() => {
    if (open) {
      setQuery('');
      setFocusIdx(0);
      commitLockRef.current = false;
      requestAnimationFrame(() => inputRef.current?.focus());
    }
  }, [open]);

  /** Transforme le texte tapé en valeur (saisie libre) si pertinent. */
  const commitFreeText = () => {
    if (!allowFree || commitLockRef.current) return;
    const q = query.trim();
    if (!q) return;
    commitLockRef.current = true;
    const exact = options.find((o) => String(o.label).toLowerCase() === q.toLowerCase());
    onChange?.(exact ?? { value: q, label: q, hint: '' });
  };

  const select = (opt) => {
    commitLockRef.current = true;
    onChange?.(opt);
    setOpen(false);
  };

  const onKey = (e) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setFocusIdx((i) => Math.min(i + 1, filtered.length - 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setFocusIdx((i) => Math.max(i - 1, 0));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filtered[focusIdx]) {
        select(filtered[focusIdx]);
      } else if (allowFree && query.trim()) {
        commitFreeText();
        setOpen(false);
      }
    } else if (e.key === 'Escape') {
      setOpen(false); // Échap = annulation : on ne valide pas le texte tapé
    }
  };

  const selectedLabel = value?.label ?? placeholder;
  const hasValue = Boolean(value?.label);

  return (
    <div className="field" ref={rootRef} style={{ position: 'relative', width }}>
      <button
        type="button"
        className="btn"
        style={{ width: '100%', justifyContent: 'flex-start' }}
        onClick={() => setOpen((o) => !o)}
        aria-haspopup="listbox"
        aria-expanded={open}
      >
        <Icon name={icon} size={17} />
        <span className="grow" style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', textAlign: 'left' }}>
          {selectedLabel}
        </span>
        {hasValue && clearable ? (
          <span
            role="button"
            tabIndex={-1}
            aria-label="Effacer la sélection"
            title="Effacer"
            style={{ display: 'grid', placeItems: 'center', padding: 2, borderRadius: 6, color: 'var(--text-3)', flex: 'none' }}
            onClick={(e) => {
              e.stopPropagation();
              onChange?.(null);
            }}
          >
            <Icon name="close" size={13} />
          </span>
        ) : null}
        <Icon name="chevronDown" size={15} />
      </button>

      {open ? (
        <div className="ss-list glass-strong" style={align === 'right' ? { left: 'auto', right: 0 } : undefined} role="listbox">
          <div style={{ padding: '10px 12px', borderBottom: '1px solid var(--glass-border)' }}>
            <div style={{ position: 'relative' }}>
              <span style={{ position: 'absolute', left: 10, top: 10, color: 'var(--text-3)' }}>
                <Icon name="search" size={15} />
              </span>
              <input
                ref={inputRef}
                className="input"
                style={{ paddingLeft: 34, paddingTop: 8, paddingBottom: 8 }}
                placeholder={placeholder}
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setFocusIdx(0);
                  onQuery?.(e.target.value);
                }}
                onKeyDown={onKey}
              />
            </div>
          </div>
          <div style={{ maxHeight: 220, overflowY: 'auto' }}>
            {filtered.length === 0 ? (
              <div className="faint small" style={{ padding: '16px 16px', textAlign: 'center' }}>
                {allowFree && query.trim() ? (
                  <>
                    Aucune suggestion — appuyez sur <strong>Entrée</strong> (ou cliquez ailleurs) pour
                    utiliser « {query.trim()} » tel quel.
                  </>
                ) : (
                  <>Aucun résultat pour « {query} »</>
                )}
              </div>
            ) : (
              filtered.map((o, i) => (
                <button
                  key={String(o.value)}
                  type="button"
                  className={`ss-item ${i === focusIdx ? 'focused' : ''}`}
                  role="option"
                  aria-selected={value?.value === o.value}
                  onMouseEnter={() => setFocusIdx(i)}
                  onClick={() => select(o)}
                >
                  <span style={{ display: 'flex', alignItems: 'center', gap: 9, minWidth: 0 }}>
                    {o.icon ? <Icon name={o.icon} size={16} /> : null}
                    <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{o.label}</span>
                  </span>
                  {o.hint ? <span className="faint xsmall" style={{ whiteSpace: 'nowrap' }}>{o.hint}</span> : null}
                </button>
              ))
            )}
          </div>
        </div>
      ) : null}
    </div>
  );
}

import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Configuration Vite — PronoScope
// Build statique optimisé, déployable tel quel sur Netlify.
export default defineConfig({
  plugins: [react()],
  build: {
    outDir: 'dist',
    sourcemap: false,
    target: 'es2020',
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom', 'react-router-dom'],
          supabase: ['@supabase/supabase-js']
        }
      }
    }
  },
  server: {
    port: 5173,
    host: true
  }
});
